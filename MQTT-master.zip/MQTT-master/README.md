# REST-API Server + MQTT Client
ESP8266 + MQTT Client + Rest API 

```bash 
npm install
node server.js
```
